# app/models/user.py

from sqlalchemy import Column, Integer, String, Enum as SQLEnum, Boolean, DateTime, func
from sqlalchemy.orm import relationship
from ..db.database import Base
import enum

# ===============================
# 🎯 ENUM des rôles utilisateurs
# ===============================
class UserRole(str, enum.Enum):
    """
    Rôles disponibles pour le contrôle d'accès :
    - admin : contrôle total
    - responsable : gestion opérationnelle
    - technicien : interventions techniques
    - client : accès limité à la consultation
    """
    admin = "admin"
    responsable = "responsable"
    technicien = "technicien"
    client = "client"

# ============================================
# 👤 Modèle ORM de l'utilisateur principal
# ============================================
class User(Base):
    """
    Représente un utilisateur de l’ERP :
    utilisé pour l’authentification, la gestion des droits (RBAC), l’audit et les relations métier.

    Champs :
    - id : identifiant unique
    - username : identifiant utilisateur unique
    - full_name : nom complet
    - email : email unique (utilisé pour le login)
    - hashed_password : mot de passe hashé
    - role : rôle métier défini dans l'Enum UserRole
    - is_active : statut de l'utilisateur (actif/inactif)
    - created_at / updated_at : audit des modifications

    Relations :
    - technicien : si l'utilisateur est un technicien, lien vers table Technicien
    - notifications : notifications reçues
    - historiques : historique de ses actions ou interventions
    """

    __tablename__ = "users"

    # === Champs principaux
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(100), unique=True, index=True, nullable=False)
    full_name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(SQLEnum(UserRole), nullable=False, index=True)
    is_active = Column(Boolean, default=True, nullable=False)

    # === Audit
    created_at = Column(DateTime, server_default=func.now(), nullable=False)
    updated_at = Column(DateTime, server_default=func.now(), onupdate=func.now(), nullable=False)

    # === Relations avec autres entités
    technicien = relationship(
        "Technicien",
        uselist=False,
        back_populates="user"
    )
    notifications = relationship(
        "Notification",
        back_populates="user",
        cascade="all, delete-orphan"
    )
    historiques = relationship(
        "HistoriqueIntervention",
        back_populates="user",
        cascade="all, delete-orphan"
    )

    def __repr__(self):
        return (
            f"<User(id={self.id}, email='{self.email}', role='{self.role}', active={self.is_active})>"
        )
