# app/api/v1/auth.py

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.schemas.user import TokenRequest, TokenResponse
from app.services.auth_service import authenticate_user
from app.db.database import SessionLocal

router = APIRouter(
    prefix="/auth",
    tags=["auth"],
    responses={404: {"description": "Not found"}}
)

# Dépendance DB
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/token", response_model=TokenResponse, summary="Connexion utilisateur", description="Authentifie un utilisateur avec email + mot de passe. Retourne un token JWT si valide.")
def login(data: TokenRequest, db: Session = Depends(get_db)):
    """
    ⚙️ Endpoint de login :
    - Vérifie l'email + mot de passe.
    - Retourne un token JWT avec rôle embarqué.
    - Utilisé dans le header `Authorization: Bearer <token>`
    """
    return authenticate_user(db, data.username, data.password)
