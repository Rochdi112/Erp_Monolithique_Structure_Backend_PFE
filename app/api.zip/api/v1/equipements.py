# app/api/v1/equipements.py

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.db.database import SessionLocal
from app.schemas.equipement import EquipementCreate, EquipementOut
from app.services.equipement_service import (
    create_equipement,
    get_equipement_by_id,
    get_all_equipements,
    delete_equipement
)
from app.core.rbac import admin_required, responsable_required

router = APIRouter(
    prefix="/equipements",
    tags=["équipements"],
    responses={404: {"description": "Équipement non trouvé"}}
)

# Dépendance DB
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post(
    "/", 
    response_model=EquipementOut,
    summary="Créer un équipement",
    description="Création d’un nouvel équipement industriel (admin ou responsable uniquement).",
    dependencies=[Depends(responsable_required)]
)
def create_new_equipement(data: EquipementCreate, db: Session = Depends(get_db)):
    return create_equipement(db, data)

@router.get(
    "/", 
    response_model=List[EquipementOut],
    summary="Lister les équipements",
    description="Liste de tous les équipements disponibles (accessible à tous les rôles authentifiés)."
)
def list_equipements(db: Session = Depends(get_db)):
    return get_all_equipements(db)

@router.get(
    "/{equipement_id}", 
    response_model=EquipementOut,
    summary="Détail d’un équipement",
    description="Récupère le détail d’un équipement à partir de son ID."
)
def get_equipement(equipement_id: int, db: Session = Depends(get_db)):
    return get_equipement_by_id(db, equipement_id)

@router.delete(
    "/{equipement_id}",
    summary="Supprimer un équipement",
    description="Suppression d’un équipement industriel (admin ou responsable uniquement).",
    dependencies=[Depends(responsable_required)]
)
def delete_equipement_by_id(equipement_id: int, db: Session = Depends(get_db)):
    delete_equipement(db, equipement_id)
    return {"detail": "Équipement supprimé avec succès."}
