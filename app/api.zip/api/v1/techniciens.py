# app/api/v1/techniciens.py

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.db.database import SessionLocal
from app.schemas.technicien import TechnicienCreate, TechnicienOut, CompetenceCreate, CompetenceOut
from app.services.technicien_service import (
    create_technicien,
    get_technicien_by_id,
    get_all_techniciens,
    create_competence,
    get_all_competences
)
from app.core.rbac import admin_required, responsable_required, get_current_user

router = APIRouter(
    prefix="/techniciens",
    tags=["techniciens"],
    responses={404: {"description": "Technicien ou compétence introuvable"}}
)

# Dépendance base de données
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ---------- TECHNICIENS ----------

@router.post(
    "/",
    response_model=TechnicienOut,
    summary="Créer un technicien",
    description="Crée un technicien (lié à un utilisateur existant). Réservé à l’admin/responsable.",
    dependencies=[Depends(responsable_required)]
)
def create_new_technicien(data: TechnicienCreate, db: Session = Depends(get_db)):
    return create_technicien(db, data)

@router.get(
    "/",
    response_model=List[TechnicienOut],
    summary="Lister les techniciens",
    description="Retourne tous les techniciens avec leurs infos de base.",
)
def list_techniciens(db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return get_all_techniciens(db)

@router.get(
    "/{technicien_id}",
    response_model=TechnicienOut,
    summary="Détail d’un technicien",
    description="Retourne le détail d’un technicien, y compris ses compétences."
)
def get_technicien(technicien_id: int, db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return get_technicien_by_id(db, technicien_id)

# ---------- COMPÉTENCES ----------

@router.post(
    "/competences",
    response_model=CompetenceOut,
    summary="Créer une compétence",
    description="Crée une nouvelle compétence métier (admin/responsable uniquement).",
    dependencies=[Depends(responsable_required)]
)
def create_new_competence(data: CompetenceCreate, db: Session = Depends(get_db)):
    return create_competence(db, data)

@router.get(
    "/competences",
    response_model=List[CompetenceOut],
    summary="Lister les compétences",
    description="Retourne la liste des compétences existantes."
)
def list_competences(db: Session = Depends(get_db), user: dict = Depends(get_current_user)):
    return get_all_competences(db)
