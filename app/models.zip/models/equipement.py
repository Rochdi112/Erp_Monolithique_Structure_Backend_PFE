from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import relationship
from ..db.database import Base



class Equipement(Base):
    """
    Représente un équipement industriel :
    - Utilisé dans des interventions (correctives/préventives)
    - Sert à planifier des maintenances
    """
    __tablename__ = "equipements"

    id = Column(Integer, primary_key=True, index=True)

    nom = Column(String(255), nullable=False)                   # ex: "Compresseur N°4"
    type = Column(String(255), nullable=False)                  # ex: "Hydraulique", "Électrique"
    localisation = Column(String(255), nullable=False)          # ex: "Atelier A"
    frequence_entretien = Column(String(50), nullable=True)     # ex: "Mensuel", "Trimestriel"

    # 🔗 Relations avec interventions et planning
    interventions = relationship("Intervention", back_populates="equipement", cascade="all, delete-orphan")
    plannings = relationship("Planning", back_populates="equipement", cascade="all, delete-orphan")
