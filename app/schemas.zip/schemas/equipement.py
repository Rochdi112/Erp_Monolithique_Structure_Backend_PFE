from pydantic import BaseModel, Field
from typing import Optional


# ---------- SCHÉMA DE BASE ----------

class EquipementBase(BaseModel):
    """
    Champs de base pour un équipement :
    - nom : identifiant libre
    - type : type technique (Hydraulique, Électrique…)
    - localisation : zone physique (Atelier A, Usine B…)
    - frequence_entretien : ex: mensuel, trimestriel
    """
    nom: str
    type_equipement: str = Field(..., alias="type")
    localisation: str
    frequence_entretien: Optional[str] = None


# ---------- SCHÉMA DE CRÉATION ----------

class EquipementCreate(EquipementBase):
    """
    Schéma utilisé lors de la création d’un équipement
    """
    pass


# ---------- SCHÉMA DE RÉPONSE ----------

class EquipementOut(EquipementBase):
    """
    Schéma renvoyé par l’API en réponse :
    - inclut l’ID généré par la base
    """
    id: int

    class Config:
        orm_mode = True
        allow_population_by_field_name = True  # Pour pouvoir renvoyer "type" dans la réponse
