from pydantic import BaseModel, Field
from typing import List, Optional
from app.schemas.user import UserOut


# ---------- COMPÉTENCES ----------

class CompetenceBase(BaseModel):
    """
    Schéma de base pour une compétence (ex: mécanique, hydraulique)
    """
    nom: str


class CompetenceCreate(CompetenceBase):
    """
    Schéma utilisé pour créer une compétence
    """
    pass


class CompetenceOut(CompetenceBase):
    """
    Schéma de réponse pour une compétence
    """
    id: int

    class Config:
        orm_mode = True


# ---------- TECHNICIEN ----------

class TechnicienBase(BaseModel):
    """
    Champs communs pour un technicien :
    - Équipe d’affectation
    - Disponibilité (ex: Disponible / Indisponible)
    """
    equipe: Optional[str] = None
    disponibilite: Optional[str] = None


class TechnicienCreate(TechnicienBase):
    """
    Données nécessaires pour créer un technicien :
    - user_id lié
    - liste optionnelle d’ID de compétences
    """
    user_id: int
    competences_ids: Optional[List[int]] = Field(default_factory=list)


class TechnicienOut(TechnicienBase):
    """
    Schéma renvoyé par l’API :
    - inclut user lié et liste de compétences
    """
    id: int
    user: UserOut
    competences: List[CompetenceOut] = []

    class Config:
        orm_mode = True
