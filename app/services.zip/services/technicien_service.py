# app/services/technicien_service.py

from sqlalchemy.orm import Session
from fastapi import HTTPException, status
from app.models.technicien import Technicien, Competence
from app.models.user import User, UserRole
from app.schemas.technicien import TechnicienCreate, CompetenceCreate


# ---------- TECHNICIEN ----------

def create_technicien(db: Session, data: TechnicienCreate) -> Technicien:
    """
    Crée un nouveau technicien avec les compétences associées.

    Vérifie que l’utilisateur existe et a le rôle 'technicien'.
    Lève une erreur si l’un des IDs de compétences n’existe pas.

    Raises:
        HTTPException 404: si user_id ou compétence non trouvés
        HTTPException 400: si le user n’est pas de rôle technicien
    """
    user = db.query(User).filter(User.id == data.user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="Utilisateur lié introuvable")
    if user.role != UserRole.technicien:
        raise HTTPException(status_code=400, detail="L'utilisateur n’est pas un technicien")

    technicien = Technicien(
        user_id=data.user_id,
        equipe=data.equipe,
        disponibilite=data.disponibilite
    )

    # Lier les compétences existantes
    if data.competences_ids:
        competences = db.query(Competence).filter(
            Competence.id.in_(data.competences_ids)
        ).all()

        if len(competences) != len(data.competences_ids):
            raise HTTPException(status_code=404, detail="Une ou plusieurs compétences sont introuvables")

        technicien.competences = competences

    db.add(technicien)
    db.commit()
    db.refresh(technicien)
    return technicien


def get_technicien_by_id(db: Session, technicien_id: int) -> Technicien:
    """
    Récupère un technicien par ID. Lève 404 si inexistant.
    """
    technicien = db.query(Technicien).filter(Technicien.id == technicien_id).first()
    if not technicien:
        raise HTTPException(status_code=404, detail="Technicien introuvable")
    return technicien


def get_all_techniciens(db: Session) -> list[Technicien]:
    """
    Retourne tous les techniciens de la base.
    """
    return db.query(Technicien).all()


# ---------- COMPÉTENCE ----------

def create_competence(db: Session, data: CompetenceCreate) -> Competence:
    """
    Crée une nouvelle compétence. Vérifie l’unicité par nom.

    Raises:
        HTTPException 400: si le nom existe déjà.
    """
    existing = db.query(Competence).filter(Competence.nom == data.nom).first()
    if existing:
        raise HTTPException(status_code=400, detail="Compétence déjà existante")
    
    competence = Competence(nom=data.nom)
    db.add(competence)
    db.commit()
    db.refresh(competence)
    return competence


def get_all_competences(db: Session) -> list[Competence]:
    """
    Liste toutes les compétences enregistrées.
    """
    return db.query(Competence).all()
